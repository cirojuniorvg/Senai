package br.senai.aulas.saep_biblioteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaepBibliotecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
