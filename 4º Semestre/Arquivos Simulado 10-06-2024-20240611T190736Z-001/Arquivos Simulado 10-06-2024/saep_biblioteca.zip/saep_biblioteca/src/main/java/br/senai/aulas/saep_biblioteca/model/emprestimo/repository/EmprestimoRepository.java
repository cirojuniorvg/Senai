package br.senai.aulas.saep_biblioteca.model.emprestimo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import br.senai.aulas.saep_biblioteca.model.emprestimo.entity.Emprestimo;

public interface EmprestimoRepository extends JpaRepository<Emprestimo, Integer> {

	public List<Emprestimo> findByLivroTituloContaining(String titulo);
}
