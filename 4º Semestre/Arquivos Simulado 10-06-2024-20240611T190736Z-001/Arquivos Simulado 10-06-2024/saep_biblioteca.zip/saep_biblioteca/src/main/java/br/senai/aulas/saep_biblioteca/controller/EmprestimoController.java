package br.senai.aulas.saep_biblioteca.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.senai.aulas.saep_biblioteca.model.emprestimo.entity.Emprestimo;
import br.senai.aulas.saep_biblioteca.model.emprestimo.service.EmprestimoService;

@RestController
@RequestMapping("/emprestimo")
@CrossOrigin(origins = "*")
public class EmprestimoController {
	
	@Autowired
	private EmprestimoService emprestimoService;
	
	@GetMapping
	public ResponseEntity<List<Emprestimo>> buscarEmprestimos() {
		return ResponseEntity.ok(emprestimoService.buscarEmprestimos());
	}

}
