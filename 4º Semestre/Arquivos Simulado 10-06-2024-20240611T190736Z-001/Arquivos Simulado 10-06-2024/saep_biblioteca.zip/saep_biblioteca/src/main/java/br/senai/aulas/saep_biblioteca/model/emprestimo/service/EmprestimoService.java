package br.senai.aulas.saep_biblioteca.model.emprestimo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.senai.aulas.saep_biblioteca.model.emprestimo.entity.Emprestimo;
import br.senai.aulas.saep_biblioteca.model.emprestimo.repository.EmprestimoRepository;

@Service
public class EmprestimoService {

	@Autowired
	private EmprestimoRepository emprestimoRepository;
	
	public List<Emprestimo> buscarEmprestimos() {
		return emprestimoRepository.findAll();
	}
}
