import axios from "axios";

const BASE_URL = "http://localhost:8080/biblioteca/emprestimo"

export const buscarEmprestimos = () => {
    return axios.get(BASE_URL)
        .then(response => response.data);
}