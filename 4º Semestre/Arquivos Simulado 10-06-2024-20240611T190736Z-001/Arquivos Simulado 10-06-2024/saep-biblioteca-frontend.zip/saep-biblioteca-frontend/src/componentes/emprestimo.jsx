import { useEffect, useState } from "react";
import { buscarEmprestimos } from "../services/emprestimo";

const ListagemEmprestimo = props => {
    const [emprestimos, setEmprestimos] = useState();

    const carregarEmprestimos = async () => {
        const emprestimos = await buscarEmprestimos();
        setEmprestimos(emprestimos);
    }

    useEffect(() => {
        carregarEmprestimos();
    },[])

    return (
        <table>
            <tr>
                <th>Estudante</th>
                <th>Livro</th>
                <th>Data Retirada</th>
            </tr>
            {emprestimos && emprestimos.map(emprestimo => <tr>
                <td>{emprestimo.estudante.nome}</td>
                <td>{emprestimo.livro.titulo}</td>
                <td>{emprestimo.dataRetirada}</td>
            </tr>)}
        </table>
    )
}

export default ListagemEmprestimo;