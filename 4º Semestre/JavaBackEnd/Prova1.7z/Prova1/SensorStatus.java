package Prova1;

public enum SensorStatus {
    OPERATIONAL,
    DEAD
}
