package Prova1;

public enum Intensity {
    HIGH,
    MEDIUM,
    LOW
}
