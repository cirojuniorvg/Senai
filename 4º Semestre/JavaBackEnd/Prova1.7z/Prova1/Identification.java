package Prova1;

public enum Identification {
    HUMAN,
    SATELLITE,
    SENSOR
}
