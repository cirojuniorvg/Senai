package Prova1;

public enum Status {
    ACTIVE,
    CONTROLLED,
    EXTINCT
}
