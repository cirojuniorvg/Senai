package com.senai.pets;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PetsApplicationTests {

	@Test
	void contextLoads() {
	}

}
