package com.senai.pets.entities.enums;

public enum OrderStatus {
    PLACED, APROVED, DELIVERED
}