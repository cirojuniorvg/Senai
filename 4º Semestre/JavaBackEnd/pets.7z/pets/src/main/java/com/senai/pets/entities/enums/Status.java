package com.senai.pets.entities.enums;

public enum Status {
    AVAILABLE, PENDING, SOLD
}
