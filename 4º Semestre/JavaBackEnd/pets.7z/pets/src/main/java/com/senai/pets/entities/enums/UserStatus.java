package com.senai.pets.entities.enums;

public enum UserStatus {
    ACTIVE, DEACTIVE
}